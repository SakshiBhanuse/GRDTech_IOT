const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const store = require('../data/store');

// ---- FEATURES ----
router.get('/features', (req, res) => res.json({ success: true, data: store.features }));
router.put('/features/:id', (req, res) => {
  const f = store.features.find(f => f.id === req.params.id);
  if (!f) return res.status(404).json({ success: false, message: 'Feature not found' });
  Object.assign(f, req.body);
  res.json({ success: true, data: f });
});
router.post('/features', (req, res) => {
  const feature = { id: uuidv4(), ...req.body };
  store.features.push(feature);
  res.status(201).json({ success: true, data: feature });
});

// ---- CONNECTIONS ----
router.get('/connections', (req, res) => res.json({ success: true, data: store.connections }));
router.post('/connections', (req, res) => {
  const conn = { id: uuidv4(), status: 'disconnected', ...req.body };
  store.connections.push(conn);
  res.status(201).json({ success: true, data: conn });
});
router.put('/connections/:id', (req, res) => {
  const c = store.connections.find(c => c.id === req.params.id);
  if (!c) return res.status(404).json({ success: false, message: 'Connection not found' });
  Object.assign(c, req.body);
  res.json({ success: true, data: c });
});
router.delete('/connections/:id', (req, res) => {
  const idx = store.connections.findIndex(c => c.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, message: 'Not found' });
  store.connections.splice(idx, 1);
  res.json({ success: true, message: 'Connection removed' });
});

// ---- POLICIES ----
router.get('/policies', (req, res) => res.json({ success: true, data: store.policies }));
router.post('/policies', (req, res) => {
  const policy = { id: uuidv4(), active: true, ...req.body };
  store.policies.push(policy);
  res.status(201).json({ success: true, data: policy });
});
router.put('/policies/:id', (req, res) => {
  const p = store.policies.find(p => p.id === req.params.id);
  if (!p) return res.status(404).json({ success: false, message: 'Policy not found' });
  Object.assign(p, req.body);
  res.json({ success: true, data: p });
});
router.delete('/policies/:id', (req, res) => {
  const idx = store.policies.findIndex(p => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, message: 'Not found' });
  store.policies.splice(idx, 1);
  res.json({ success: true, message: 'Policy deleted' });
});

// ---- DATA MANAGEMENT ----
router.get('/data', (req, res) => res.json({ success: true, data: store.dataRecords }));
router.post('/data', (req, res) => {
  const record = { id: uuidv4(), timestamp: new Date().toISOString(), ...req.body };
  store.dataRecords.push(record);
  res.status(201).json({ success: true, data: record });
});
router.delete('/data/:id', (req, res) => {
  const idx = store.dataRecords.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, message: 'Not found' });
  store.dataRecords.splice(idx, 1);
  res.json({ success: true, message: 'Record deleted' });
});

module.exports = router;
