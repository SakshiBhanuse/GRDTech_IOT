const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const store = require('../data/store');

// GET all devices
router.get('/', (req, res) => {
  res.json({ success: true, data: store.devices });
});

// GET device stats
router.get('/stats', (req, res) => {
  const total = store.devices.length;
  const active = store.devices.filter(d => d.status === 'active').length;
  const provisioned = store.devices.filter(d => d.provisioned).length;
  const lastRegistered = store.devices.sort((a, b) => new Date(b.lastSeen) - new Date(a.lastSeen))[0];
  res.json({ success: true, data: { total, active, provisioned, lastRegistered: lastRegistered?.name || '-' } });
});

// GET single device
router.get('/:id', (req, res) => {
  const device = store.devices.find(d => d.id === req.params.id);
  if (!device) return res.status(404).json({ success: false, message: 'Device not found' });
  res.json({ success: true, data: device });
});

// POST create device
router.post('/', (req, res) => {
  const { name, type, location, ip, firmware } = req.body;
  if (!name || !type) return res.status(400).json({ success: false, message: 'Name and type are required' });
  const device = {
    id: uuidv4(),
    name, type,
    status: 'inactive',
    provisioned: false,
    lastSeen: new Date().toISOString(),
    location: location || 'Unknown',
    ip: ip || '0.0.0.0',
    firmware: firmware || 'v1.0.0',
    telemetry: {}
  };
  store.devices.push(device);
  res.status(201).json({ success: true, data: device });
});

// PUT update device
router.put('/:id', (req, res) => {
  const idx = store.devices.findIndex(d => d.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, message: 'Device not found' });
  store.devices[idx] = { ...store.devices[idx], ...req.body, id: req.params.id };
  res.json({ success: true, data: store.devices[idx] });
});

// DELETE device
router.delete('/:id', (req, res) => {
  const idx = store.devices.findIndex(d => d.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, message: 'Device not found' });
  store.devices.splice(idx, 1);
  res.json({ success: true, message: 'Device deleted' });
});

// POST provision device
router.post('/:id/provision', (req, res) => {
  const device = store.devices.find(d => d.id === req.params.id);
  if (!device) return res.status(404).json({ success: false, message: 'Device not found' });
  device.provisioned = true;
  device.status = 'active';
  device.lastSeen = new Date().toISOString();
  res.json({ success: true, data: device, message: 'Device provisioned successfully' });
});

module.exports = router;
