const express = require('express');
const cors = require('cors');
const deviceRoutes = require('./routes/devices');
const otherRoutes = require('./routes/other');
const authRoutes = require('./routes/auth');
const { authMiddleware } = require('./middleware/auth');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// ── PUBLIC routes (no login needed)
app.use('/api/auth', authRoutes);
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'GRDTECH-IOT API running', timestamp: new Date().toISOString() });
});

// ── PROTECTED routes (login required)
app.use('/api/devices', authMiddleware, deviceRoutes);
app.use('/api', authMiddleware, otherRoutes);

app.listen(PORT, () => {
  console.log(`\n🚀 GRDTECH-IOT Backend running at http://localhost:${PORT}`);
  console.log(`\n🔐 Default Login Credentials:`);
  console.log(`   Admin  → admin@grdtech.io  /  Admin@123`);
  console.log(`   User   → user@grdtech.io   /  User@123`);
  console.log(`\n   Health: http://localhost:${PORT}/api/health\n`);
});
