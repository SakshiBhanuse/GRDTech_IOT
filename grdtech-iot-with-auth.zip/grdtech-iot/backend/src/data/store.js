const { v4: uuidv4 } = require('uuid');

// In-memory data store (replaces DB for local dev)
const store = {
  devices: [
    {
      id: uuidv4(),
      name: 'Temperature Sensor A1',
      type: 'sensor',
      status: 'active',
      provisioned: true,
      lastSeen: new Date().toISOString(),
      location: 'Building A',
      ip: '192.168.1.101',
      firmware: 'v2.1.0',
      telemetry: { temperature: 24.5, humidity: 60 }
    },
    {
      id: uuidv4(),
      name: 'Gateway Node B2',
      type: 'gateway',
      status: 'active',
      provisioned: true,
      lastSeen: new Date().toISOString(),
      location: 'Building B',
      ip: '192.168.1.102',
      firmware: 'v1.8.3',
      telemetry: { uptime: 99.9, packets: 1024 }
    },
    {
      id: uuidv4(),
      name: 'Humidity Sensor C3',
      type: 'sensor',
      status: 'inactive',
      provisioned: false,
      lastSeen: new Date(Date.now() - 86400000).toISOString(),
      location: 'Building C',
      ip: '192.168.1.103',
      firmware: 'v2.0.1',
      telemetry: { humidity: 45 }
    }
  ],
  policies: [
    { id: uuidv4(), name: 'Default Read Policy', type: 'read', scope: 'all', active: true },
    { id: uuidv4(), name: 'Admin Write Policy', type: 'write', scope: 'admin', active: true }
  ],
  connections: [
    { id: uuidv4(), name: 'MQTT Broker', protocol: 'MQTT', host: 'localhost', port: 1883, status: 'connected' },
    { id: uuidv4(), name: 'HTTP Endpoint', protocol: 'HTTP', host: 'api.grdtech.io', port: 443, status: 'connected' }
  ],
  features: [
    { id: uuidv4(), name: 'Real-time Telemetry', enabled: true, category: 'data' },
    { id: uuidv4(), name: 'OTA Updates', enabled: true, category: 'management' },
    { id: uuidv4(), name: 'Geofencing', enabled: false, category: 'location' },
    { id: uuidv4(), name: 'Anomaly Detection', enabled: false, category: 'analytics' }
  ],
  dataRecords: []
};

module.exports = store;
