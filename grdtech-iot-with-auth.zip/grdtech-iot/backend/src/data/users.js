// Pre-defined users (in a real app, this would be a database)
// Default credentials:
//   Admin  → email: admin@grdtech.io   password: Admin@123
//   User   → email: user@grdtech.io    password: User@123

const bcrypt = require('bcryptjs');

const users = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@grdtech.io',
    // bcrypt hash of "Admin@123"
    password: bcrypt.hashSync('Admin@123', 10),
    role: 'admin',
    avatar: 'AU',
  },
  {
    id: '2',
    name: 'Engineer User',
    email: 'user@grdtech.io',
    // bcrypt hash of "User@123"
    password: bcrypt.hashSync('User@123', 10),
    role: 'user',
    avatar: 'EU',
  },
];

module.exports = users;
