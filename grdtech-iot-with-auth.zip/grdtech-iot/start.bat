@echo off
echo ========================================
echo   GRDTECH-IOT - Starting Application
echo ========================================
echo.

echo [1/2] Installing Backend dependencies...
cd backend
call npm install
echo Backend ready.
echo.

echo [2/2] Installing Frontend dependencies...
cd ../frontend
call npm install
echo Frontend ready.
echo.

echo Starting Backend server in new window...
start "GRDTECH Backend" cmd /k "cd /d %~dp0backend && npm start"

echo Waiting 3 seconds...
timeout /t 3 /nobreak >nul

echo Starting Frontend in new window...
start "GRDTECH Frontend" cmd /k "cd /d %~dp0frontend && npm start"

echo.
echo ========================================
echo  Both servers starting!
echo  Frontend: http://localhost:3000
echo  Backend:  http://localhost:5000
echo ========================================
pause
