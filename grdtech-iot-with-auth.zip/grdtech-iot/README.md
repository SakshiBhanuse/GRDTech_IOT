# GRDTECH-IOT | IoT Suite

A full-stack IoT Device Management Platform built with React (frontend) and Node.js/Express (backend).

---

## Project Structure

```
grdtech-iot/
├── backend/
│   ├── package.json
│   └── src/
│       ├── server.js
│       ├── data/store.js
│       └── routes/
│           ├── devices.js
│           └── other.js
├── frontend/
│   ├── package.json
│   ├── public/
│   │   └── index.html
│   └── src/
│       ├── App.js
│       ├── index.js
│       ├── index.css
│       ├── api.js
│       ├── components/
│       │   └── Sidebar.js
│       └── pages/
│           ├── Dashboard.js
│           ├── Devices.js
│           ├── Provisioning.js
│           ├── Features.js
│           ├── Connections.js
│           ├── Policies.js
│           └── DataManagement.js
└── README.md
```

---

## Features

- **Dashboard** – Stats overview (Total, Active, Provisioned devices) + Charts
- **Devices** – Full CRUD: Add, Edit, Delete, Provision devices
- **Device Provisioning** – View pending & provisioned devices
- **Features** – Toggle IoT features on/off
- **Connections** – Manage MQTT/HTTP/WebSocket connections
- **Policies & Access Control** – Create and manage access policies
- **Device & Data Management** – Log and manage telemetry/event data

---

## Requirements

- Node.js v16 or higher
- npm v8 or higher

---

## HOW TO RUN (Step-by-Step)

### Step 1 – Install Backend Dependencies
```
cd grdtech-iot/backend
npm install
```

### Step 2 – Start the Backend Server
```
npm start
```
You should see: `🚀 GRDTECH-IOT Backend running at http://localhost:5000`

### Step 3 – Open a NEW terminal window

### Step 4 – Install Frontend Dependencies
```
cd grdtech-iot/frontend
npm install
```
(This may take 2–3 minutes the first time)

### Step 5 – Start the Frontend
```
npm start
```
The browser will automatically open at http://localhost:3000

---

## Both servers must run simultaneously.
- Backend: http://localhost:5000
- Frontend: http://localhost:3000
