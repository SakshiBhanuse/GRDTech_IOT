import React, { useState } from 'react';

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: '📊' },
  {
    id: 'devices', label: 'Devices', icon: '📡',
    children: [
      { id: 'devices-list', label: 'Device List' },
      { id: 'devices-add', label: 'Add Device' }
    ]
  },
  {
    id: 'provisioning', label: 'Device Provisioning', icon: '⚙️',
    children: [
      { id: 'provisioning-list', label: 'Provisioning List' }
    ]
  },
  {
    id: 'features', label: 'Features', icon: '🔧',
    children: [
      { id: 'features-list', label: 'Feature Management' }
    ]
  },
  {
    id: 'connections', label: 'Connections', icon: '🔗',
    children: [
      { id: 'connections-list', label: 'Connection Manager' }
    ]
  },
  {
    id: 'policies', label: 'Policies & Access Control', icon: '🛡️',
    children: [
      { id: 'policies-list', label: 'Policy Manager' }
    ]
  },
  { id: 'data', label: 'Device & Data Management', icon: '🗄️' }
];

export default function Sidebar({ activePage, onNavigate }) {
  const [openMenus, setOpenMenus] = useState({ devices: true });

  const toggleMenu = (id) => setOpenMenus(prev => ({ ...prev, [id]: !prev[id] }));

  const isActive = (item) => {
    if (item.id === activePage) return true;
    if (item.children) return item.children.some(c => c.id === activePage);
    return false;
  };

  return (
    <div className="sidebar">
      <div className="sidebar-brand">
        <div className="brand-dot" />
        <span className="brand-name">GRDTECH-IOT</span>
      </div>
      <nav className="sidebar-nav">
        {navItems.map(item => (
          <div key={item.id}>
            <div
              className={`nav-item ${isActive(item) ? 'active' : ''} ${openMenus[item.id] ? 'open' : ''}`}
              onClick={() => {
                if (item.children) toggleMenu(item.id);
                else onNavigate(item.id);
              }}
            >
              <span className="nav-icon">{item.icon}</span>
              <span>{item.label}</span>
              {item.children && <span className="nav-arrow">▾</span>}
            </div>
            {item.children && openMenus[item.id] && (
              <div className="nav-submenu">
                {item.children.map(child => (
                  <div
                    key={child.id}
                    className={`nav-item ${activePage === child.id ? 'active' : ''}`}
                    onClick={() => onNavigate(child.id)}
                  >
                    {child.label}
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </nav>
    </div>
  );
}
