import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Devices from './pages/Devices';
import Provisioning from './pages/Provisioning';
import Features from './pages/Features';
import Connections from './pages/Connections';
import Policies from './pages/Policies';
import DataManagement from './pages/DataManagement';
import Login from './pages/Login';

const PAGE_TITLES = {
  dashboard: 'Dashboard',
  'devices-list': 'Devices',
  'devices-add': 'Add Device',
  'provisioning-list': 'Device Provisioning',
  'features-list': 'Features',
  'connections-list': 'Connections',
  'policies-list': 'Policies & Access Control',
  data: 'Device & Data Management'
};

export default function App() {
  const [page, setPage] = useState('dashboard');
  const [addDevice, setAddDevice] = useState(false);
  const [user, setUser] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);

  // On load — check if already logged in
  useEffect(() => {
    const savedUser  = localStorage.getItem('grdtech_user');
    const savedToken = localStorage.getItem('grdtech_token');
    if (savedUser && savedToken) {
      setUser(JSON.parse(savedUser));
    }
    setAuthChecked(true);
  }, []);

  const handleLogin = (userData) => {
    setUser(userData);
  };

  const handleLogout = () => {
    localStorage.removeItem('grdtech_token');
    localStorage.removeItem('grdtech_user');
    setUser(null);
    setPage('dashboard');
  };

  const navigate = (p) => {
    if (p === 'devices-add') { setPage('devices-list'); setAddDevice(true); }
    else { setPage(p); setAddDevice(false); }
  };

  const renderPage = () => {
    switch (page) {
      case 'dashboard':         return <Dashboard />;
      case 'devices-list':      return <Devices showAdd={addDevice} onAddDone={() => setAddDevice(false)} />;
      case 'provisioning-list': return <Provisioning />;
      case 'features-list':     return <Features />;
      case 'connections-list':  return <Connections />;
      case 'policies-list':     return <Policies />;
      case 'data':              return <DataManagement />;
      default:                  return <Dashboard />;
    }
  };

  // Wait until auth check is done
  if (!authChecked) return null;

  // Not logged in → show Login page
  if (!user) return <Login onLogin={handleLogin} />;

  // Logged in → show full dashboard
  return (
    <div className="app-layout">
      <Sidebar activePage={page} onNavigate={navigate} />
      <div className="main-content">

        {/* Top Bar */}
        <div className="topbar">
          <span className="topbar-title">{PAGE_TITLES[page] || 'GRDTECH-IOT'}</span>
          <div className="topbar-right">
            <div className="status-badge">
              <div className="status-dot" />
              System Online
            </div>
            <span style={{ color: '#9da5b4', fontSize: 13 }}>
              {new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
            </span>

            {/* User Avatar + Info */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{
                width: 36, height: 36, borderRadius: '50%',
                background: 'linear-gradient(135deg, #2D9CDB, #00C2CB)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 13, fontWeight: 700, color: '#fff', flexShrink: 0,
              }}>
                {user.avatar || user.name?.substring(0, 2).toUpperCase()}
              </div>
              <div style={{ lineHeight: 1.3 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: '#e8eaf0' }}>{user.name}</div>
                <div style={{ fontSize: 11, color: '#9da5b4', textTransform: 'capitalize' }}>{user.role}</div>
              </div>
              <button
                onClick={handleLogout}
                style={{
                  background: 'rgba(231,76,60,0.12)', border: '1px solid rgba(231,76,60,0.3)',
                  color: '#e74c3c', padding: '6px 14px', borderRadius: 7,
                  fontSize: 12, fontWeight: 500, cursor: 'pointer',
                  fontFamily: "'Inter', sans-serif", transition: 'all 0.2s',
                }}
                onMouseEnter={e => e.target.style.background = 'rgba(231,76,60,0.25)'}
                onMouseLeave={e => e.target.style.background = 'rgba(231,76,60,0.12)'}
              >
                🚪 Logout
              </button>
            </div>
          </div>
        </div>

        <div className="page-content">
          {renderPage()}
        </div>
      </div>
    </div>
  );
}
