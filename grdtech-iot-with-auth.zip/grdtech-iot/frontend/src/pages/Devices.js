import React, { useEffect, useState } from 'react';
import { getDevices, createDevice, deleteDevice, provisionDevice, updateDevice } from '../api';

function Modal({ title, onClose, children }) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-title">{title}</div>
        {children}
      </div>
    </div>
  );
}

export default function Devices({ showAdd, onAddDone }) {
  const [devices, setDevices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editDevice, setEditDevice] = useState(null);
  const [form, setForm] = useState({ name: '', type: 'sensor', location: '', ip: '', firmware: '' });
  const [msg, setMsg] = useState('');

  const load = () => {
    setLoading(true);
    getDevices().then(r => setDevices(r.data.data)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);
  useEffect(() => { if (showAdd) { setShowModal(true); onAddDone && onAddDone(); } }, [showAdd]);

  const openAdd = () => { setForm({ name: '', type: 'sensor', location: '', ip: '', firmware: '' }); setEditDevice(null); setShowModal(true); };
  const openEdit = (d) => { setForm({ name: d.name, type: d.type, location: d.location, ip: d.ip, firmware: d.firmware }); setEditDevice(d); setShowModal(true); };

  const handleSubmit = async () => {
    try {
      if (editDevice) await updateDevice(editDevice.id, form);
      else await createDevice(form);
      setShowModal(false); setMsg(''); load();
    } catch { setMsg('Error saving device'); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this device?')) return;
    await deleteDevice(id); load();
  };

  const handleProvision = async (id) => {
    await provisionDevice(id); load();
  };

  return (
    <div>
      <div className="section-header">
        <span className="section-title">Device List</span>
        <button className="btn btn-primary" onClick={openAdd}>＋ Add Device</button>
      </div>

      <div className="table-card">
        {loading ? (
          <div className="loading"><div className="spinner" /></div>
        ) : devices.length === 0 ? (
          <div className="empty-state"><div className="icon">📡</div><p>No devices yet. Add one!</p></div>
        ) : (
          <table>
            <thead>
              <tr><th>Name</th><th>Type</th><th>Status</th><th>Provisioned</th><th>Location</th><th>IP</th><th>Firmware</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {devices.map(d => (
                <tr key={d.id}>
                  <td><strong>{d.name}</strong></td>
                  <td style={{ textTransform: 'capitalize' }}>{d.type}</td>
                  <td><span className={`badge badge-${d.status}`}>{d.status}</span></td>
                  <td>
                    <span className={`badge ${d.provisioned ? 'badge-provisioned' : 'badge-pending'}`}>
                      {d.provisioned ? 'Yes' : 'Pending'}
                    </span>
                  </td>
                  <td>{d.location}</td>
                  <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{d.ip}</td>
                  <td style={{ color: '#9da5b4' }}>{d.firmware}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 6 }}>
                      {!d.provisioned && (
                        <button className="btn btn-success btn-sm" onClick={() => handleProvision(d.id)}>Provision</button>
                      )}
                      <button className="btn btn-outline btn-sm" onClick={() => openEdit(d)}>Edit</button>
                      <button className="btn btn-danger btn-sm" onClick={() => handleDelete(d.id)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <Modal title={editDevice ? 'Edit Device' : 'Add New Device'} onClose={() => setShowModal(false)}>
          {msg && <div className="alert alert-error">{msg}</div>}
          <div className="form-group">
            <label className="form-label">Device Name *</label>
            <input className="form-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Temperature Sensor A1" />
          </div>
          <div className="form-group">
            <label className="form-label">Type *</label>
            <select className="form-select" value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}>
              <option value="sensor">Sensor</option>
              <option value="gateway">Gateway</option>
              <option value="actuator">Actuator</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Location</label>
            <input className="form-input" value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} placeholder="e.g. Building A" />
          </div>
          <div className="form-group">
            <label className="form-label">IP Address</label>
            <input className="form-input" value={form.ip} onChange={e => setForm({ ...form, ip: e.target.value })} placeholder="192.168.1.100" />
          </div>
          <div className="form-group">
            <label className="form-label">Firmware Version</label>
            <input className="form-input" value={form.firmware} onChange={e => setForm({ ...form, firmware: e.target.value })} placeholder="v1.0.0" />
          </div>
          <div className="modal-actions">
            <button className="btn btn-outline" onClick={() => setShowModal(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={handleSubmit}>{editDevice ? 'Update' : 'Create'} Device</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
