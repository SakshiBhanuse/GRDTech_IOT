import React, { useEffect, useState } from 'react';
import { getFeatures, updateFeature, createFeature } from '../api';

export default function Features() {
  const [features, setFeatures] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name: '', category: 'data', enabled: false });

  const load = () => {
    setLoading(true);
    getFeatures().then(r => setFeatures(r.data.data)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const toggle = async (f) => {
    await updateFeature(f.id, { ...f, enabled: !f.enabled });
    load();
  };

  const handleCreate = async () => {
    await createFeature(form);
    setShowModal(false);
    setForm({ name: '', category: 'data', enabled: false });
    load();
  };

  const grouped = features.reduce((acc, f) => {
    if (!acc[f.category]) acc[f.category] = [];
    acc[f.category].push(f);
    return acc;
  }, {});

  return (
    <div>
      <div className="section-header">
        <span className="section-title">Feature Management</span>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>＋ Add Feature</button>
      </div>

      {loading ? (
        <div className="loading"><div className="spinner" /></div>
      ) : (
        Object.entries(grouped).map(([cat, feats]) => (
          <div key={cat} style={{ marginBottom: 28 }}>
            <div style={{ fontSize: 12, color: '#9da5b4', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: 12, fontWeight: 600 }}>
              {cat}
            </div>
            <div className="feature-grid">
              {feats.map(f => (
                <div className="feature-card" key={f.id}>
                  <div className="feature-info">
                    <h4>{f.name}</h4>
                    <p>{f.category}</p>
                  </div>
                  <button className={`toggle ${f.enabled ? 'on' : ''}`} onClick={() => toggle(f)} />
                </div>
              ))}
            </div>
          </div>
        ))
      )}

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-title">Add Feature</div>
            <div className="form-group">
              <label className="form-label">Feature Name</label>
              <input className="form-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Auto-scaling" />
            </div>
            <div className="form-group">
              <label className="form-label">Category</label>
              <select className="form-select" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
                <option value="data">Data</option>
                <option value="management">Management</option>
                <option value="location">Location</option>
                <option value="analytics">Analytics</option>
                <option value="security">Security</option>
              </select>
            </div>
            <div className="modal-actions">
              <button className="btn btn-outline" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleCreate}>Create Feature</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
