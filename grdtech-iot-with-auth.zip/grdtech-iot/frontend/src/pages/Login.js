import React, { useState } from 'react';
import { loginUser, registerUser } from '../api';

export default function Login({ onLogin }) {
  const [tab, setTab]         = useState('login'); // 'login' | 'register'
  const [form, setForm]       = useState({ name: '', email: '', password: '', confirm: '' });
  const [showPass, setShowPass]       = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');
  const [success, setSuccess] = useState('');

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleLogin = async (e) => {
    e.preventDefault();
    setError(''); setSuccess('');
    if (!form.email || !form.password) { setError('Please enter email and password.'); return; }
    setLoading(true);
    try {
      const res = await loginUser({ email: form.email, password: form.password });
      localStorage.setItem('grdtech_token', res.data.token);
      localStorage.setItem('grdtech_user', JSON.stringify(res.data.user));
      onLogin(res.data.user);
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Please try again.');
    } finally { setLoading(false); }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setError(''); setSuccess('');
    if (!form.name || !form.email || !form.password) { setError('All fields are required.'); return; }
    if (form.password !== form.confirm) { setError('Passwords do not match.'); return; }
    if (form.password.length < 6) { setError('Password must be at least 6 characters.'); return; }
    setLoading(true);
    try {
      const res = await registerUser({ name: form.name, email: form.email, password: form.password });
      localStorage.setItem('grdtech_token', res.data.token);
      localStorage.setItem('grdtech_user', JSON.stringify(res.data.user));
      setSuccess('Account created! Redirecting...');
      setTimeout(() => onLogin(res.data.user), 800);
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed.');
    } finally { setLoading(false); }
  };

  return (
    <div style={styles.bg}>
      {/* Animated background circles */}
      <div style={{ ...styles.circle, width: 500, height: 500, top: -150, left: -150, background: 'rgba(45,156,219,0.08)' }} />
      <div style={{ ...styles.circle, width: 350, height: 350, bottom: -100, right: -80,  background: 'rgba(0,194,203,0.07)' }} />
      <div style={{ ...styles.circle, width: 200, height: 200, top: '40%', right: '10%', background: 'rgba(242,153,74,0.06)' }} />

      <div style={styles.card}>
        {/* Logo */}
        <div style={styles.logoRow}>
          <div style={styles.logoDot} />
          <span style={styles.logoText}>GRDTECH-IOT</span>
        </div>
        <p style={styles.logoSub}>IoT Device Management Platform</p>

        {/* Tabs */}
        <div style={styles.tabs}>
          <button style={{ ...styles.tab, ...(tab === 'login' ? styles.tabActive : {}) }} onClick={() => { setTab('login'); setError(''); setSuccess(''); }}>
            Login
          </button>
          <button style={{ ...styles.tab, ...(tab === 'register' ? styles.tabActive : {}) }} onClick={() => { setTab('register'); setError(''); setSuccess(''); }}>
            Register
          </button>
        </div>

        {/* Error / Success */}
        {error   && <div style={styles.alertErr}>{error}</div>}
        {success && <div style={styles.alertOk}>{success}</div>}

        {/* ── LOGIN FORM ── */}
        {tab === 'login' && (
          <form onSubmit={handleLogin}>
            <div style={styles.field}>
              <label style={styles.label}>Email Address</label>
              <div style={styles.inputWrap}>
                <span style={styles.icon}>✉️</span>
                <input
                  style={styles.input}
                  type="email"
                  placeholder="admin@grdtech.io"
                  value={form.email}
                  onChange={e => update('email', e.target.value)}
                  autoComplete="email"
                />
              </div>
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Password</label>
              <div style={styles.inputWrap}>
                <span style={styles.icon}>🔒</span>
                <input
                  style={styles.input}
                  type={showPass ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={form.password}
                  onChange={e => update('password', e.target.value)}
                  autoComplete="current-password"
                />
                <button type="button" style={styles.eye} onClick={() => setShowPass(p => !p)}>
                  {showPass ? '🙈' : '👁️'}
                </button>
              </div>
            </div>

            <button style={{ ...styles.btn, ...(loading ? styles.btnLoading : {}) }} type="submit" disabled={loading}>
              {loading ? 'Signing In...' : '🔓  Sign In'}
            </button>

            {/* Default credentials hint */}
            <div style={styles.hint}>
              <p style={styles.hintTitle}>Default Credentials</p>
              <div style={styles.hintRow}>
                <span style={styles.hintBadge}>Admin</span>
                <span style={styles.hintCred}>admin@grdtech.io  /  Admin@123</span>
              </div>
              <div style={styles.hintRow}>
                <span style={{ ...styles.hintBadge, background: 'rgba(39,174,96,0.2)', color: '#27AE60', border: '1px solid rgba(39,174,96,0.3)' }}>User</span>
                <span style={styles.hintCred}>user@grdtech.io  /  User@123</span>
              </div>
            </div>
          </form>
        )}

        {/* ── REGISTER FORM ── */}
        {tab === 'register' && (
          <form onSubmit={handleRegister}>
            <div style={styles.field}>
              <label style={styles.label}>Full Name</label>
              <div style={styles.inputWrap}>
                <span style={styles.icon}>👤</span>
                <input style={styles.input} type="text" placeholder="John Doe" value={form.name} onChange={e => update('name', e.target.value)} />
              </div>
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Email Address</label>
              <div style={styles.inputWrap}>
                <span style={styles.icon}>✉️</span>
                <input style={styles.input} type="email" placeholder="you@example.com" value={form.email} onChange={e => update('email', e.target.value)} />
              </div>
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Password</label>
              <div style={styles.inputWrap}>
                <span style={styles.icon}>🔒</span>
                <input
                  style={styles.input}
                  type={showPass ? 'text' : 'password'}
                  placeholder="Min 6 characters"
                  value={form.password}
                  onChange={e => update('password', e.target.value)}
                />
                <button type="button" style={styles.eye} onClick={() => setShowPass(p => !p)}>{showPass ? '🙈' : '👁️'}</button>
              </div>
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Confirm Password</label>
              <div style={styles.inputWrap}>
                <span style={styles.icon}>🔒</span>
                <input
                  style={styles.input}
                  type={showConfirm ? 'text' : 'password'}
                  placeholder="Re-enter password"
                  value={form.confirm}
                  onChange={e => update('confirm', e.target.value)}
                />
                <button type="button" style={styles.eye} onClick={() => setShowConfirm(p => !p)}>{showConfirm ? '🙈' : '👁️'}</button>
              </div>
            </div>

            <button style={{ ...styles.btn, ...(loading ? styles.btnLoading : {}) }} type="submit" disabled={loading}>
              {loading ? 'Creating Account...' : '🚀  Create Account'}
            </button>
          </form>
        )}

        <p style={styles.footer}>© 2024 GRDTECH-IOT • IoT Suite</p>
      </div>
    </div>
  );
}

// ── STYLES ─────────────────────────────────────────────────────
const styles = {
  bg: {
    minHeight: '100vh',
    background: 'linear-gradient(135deg, #0B1D35 0%, #112844 50%, #0B1D35 100%)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontFamily: "'Inter', sans-serif",
    position: 'relative', overflow: 'hidden',
  },
  circle: {
    position: 'absolute', borderRadius: '50%', pointerEvents: 'none',
  },
  card: {
    background: 'rgba(22, 51, 82, 0.85)',
    backdropFilter: 'blur(20px)',
    border: '1px solid rgba(45,156,219,0.25)',
    borderRadius: 16,
    padding: '36px 40px',
    width: '100%', maxWidth: 440,
    boxShadow: '0 24px 80px rgba(0,0,0,0.5)',
    position: 'relative', zIndex: 10,
  },
  logoRow: { display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 },
  logoDot: {
    width: 14, height: 14, borderRadius: '50%',
    background: '#2D9CDB', boxShadow: '0 0 10px #2D9CDB',
    animation: 'pulse 2s infinite',
  },
  logoText: {
    fontFamily: "'Rajdhani', sans-serif",
    fontSize: 22, fontWeight: 700, color: '#fff', letterSpacing: 2,
  },
  logoSub: { fontSize: 12, color: '#7FA8C9', marginBottom: 24, marginTop: 0 },

  tabs: { display: 'flex', background: 'rgba(0,0,0,0.3)', borderRadius: 8, padding: 4, marginBottom: 22, gap: 4 },
  tab: {
    flex: 1, padding: '8px 0', border: 'none', borderRadius: 6,
    background: 'transparent', color: '#7FA8C9',
    fontSize: 14, fontWeight: 500, cursor: 'pointer', transition: 'all 0.2s',
  },
  tabActive: { background: '#2D9CDB', color: '#fff', boxShadow: '0 2px 8px rgba(45,156,219,0.4)' },

  alertErr: {
    background: 'rgba(235,87,87,0.15)', border: '1px solid rgba(235,87,87,0.35)',
    color: '#EB5757', padding: '10px 14px', borderRadius: 8,
    fontSize: 13, marginBottom: 16,
  },
  alertOk: {
    background: 'rgba(39,174,96,0.15)', border: '1px solid rgba(39,174,96,0.35)',
    color: '#27AE60', padding: '10px 14px', borderRadius: 8,
    fontSize: 13, marginBottom: 16,
  },

  field: { marginBottom: 16 },
  label: { display: 'block', fontSize: 11, color: '#7FA8C9', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.7px' },
  inputWrap: {
    display: 'flex', alignItems: 'center',
    background: 'rgba(11,29,53,0.8)', border: '1px solid rgba(45,156,219,0.25)',
    borderRadius: 8, overflow: 'hidden', transition: 'border-color 0.2s',
  },
  icon: { padding: '0 12px', fontSize: 16, flexShrink: 0 },
  input: {
    flex: 1, padding: '11px 0 11px 0',
    background: 'transparent', border: 'none', outline: 'none',
    color: '#E0ECF8', fontSize: 14, fontFamily: "'Inter', sans-serif",
  },
  eye: {
    background: 'transparent', border: 'none', padding: '0 12px',
    fontSize: 15, cursor: 'pointer', color: '#7FA8C9',
  },

  btn: {
    width: '100%', padding: '13px 0', marginTop: 8,
    background: 'linear-gradient(135deg, #2D9CDB, #00C2CB)',
    border: 'none', borderRadius: 8, color: '#fff',
    fontSize: 15, fontWeight: 600, cursor: 'pointer',
    transition: 'all 0.2s', letterSpacing: 0.5,
    boxShadow: '0 4px 16px rgba(45,156,219,0.4)',
  },
  btnLoading: { opacity: 0.7, cursor: 'not-allowed' },

  hint: {
    marginTop: 20, padding: 14,
    background: 'rgba(0,0,0,0.25)', borderRadius: 8,
    border: '1px solid rgba(45,156,219,0.15)',
  },
  hintTitle: { fontSize: 11, color: '#7FA8C9', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.7px', margin: '0 0 8px 0' },
  hintRow: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 5 },
  hintBadge: {
    fontSize: 10, padding: '2px 8px', borderRadius: 10,
    background: 'rgba(45,156,219,0.2)', color: '#2D9CDB',
    border: '1px solid rgba(45,156,219,0.3)', fontWeight: 600, flexShrink: 0,
  },
  hintCred: { fontSize: 12, color: '#E0ECF8', fontFamily: 'monospace' },

  footer: { textAlign: 'center', fontSize: 11, color: '#3A5A7A', marginTop: 24, marginBottom: 0 },
};
