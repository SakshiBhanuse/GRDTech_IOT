import React, { useEffect, useState } from 'react';
import { getPolicies, createPolicy, deletePolicy, updatePolicy } from '../api';

export default function Policies() {
  const [policies, setPolicies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name: '', type: 'read', scope: 'all' });

  const load = () => {
    setLoading(true);
    getPolicies().then(r => setPolicies(r.data.data)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const handleCreate = async () => {
    await createPolicy({ ...form, active: true });
    setShowModal(false);
    setForm({ name: '', type: 'read', scope: 'all' });
    load();
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete policy?')) return;
    await deletePolicy(id); load();
  };

  const toggleActive = async (p) => {
    await updatePolicy(p.id, { ...p, active: !p.active }); load();
  };

  return (
    <div>
      <div className="section-header">
        <span className="section-title">Policies & Access Control</span>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>＋ New Policy</button>
      </div>

      <div className="table-card">
        {loading ? (
          <div className="loading"><div className="spinner" /></div>
        ) : policies.length === 0 ? (
          <div className="empty-state"><div className="icon">🛡️</div><p>No policies defined</p></div>
        ) : (
          <table>
            <thead><tr><th>Policy Name</th><th>Type</th><th>Scope</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {policies.map(p => (
                <tr key={p.id}>
                  <td><strong>{p.name}</strong></td>
                  <td>
                    <span className="badge" style={{ background: p.type === 'write' ? 'rgba(231,76,60,0.15)' : 'rgba(74,158,218,0.15)', color: p.type === 'write' ? '#e74c3c' : '#4a9eda', border: `1px solid ${p.type === 'write' ? 'rgba(231,76,60,0.3)' : 'rgba(74,158,218,0.3)'}` }}>
                      {p.type.toUpperCase()}
                    </span>
                  </td>
                  <td style={{ textTransform: 'capitalize' }}>{p.scope}</td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <button className={`toggle ${p.active ? 'on' : ''}`} onClick={() => toggleActive(p)} />
                      <span style={{ fontSize: 12, color: p.active ? '#2ecc71' : '#9da5b4' }}>{p.active ? 'Active' : 'Inactive'}</span>
                    </div>
                  </td>
                  <td>
                    <button className="btn btn-danger btn-sm" onClick={() => handleDelete(p.id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-title">New Policy</div>
            <div className="form-group">
              <label className="form-label">Policy Name</label>
              <input className="form-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Read-only Sensor Access" />
            </div>
            <div className="form-group">
              <label className="form-label">Type</label>
              <select className="form-select" value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}>
                <option value="read">Read</option>
                <option value="write">Write</option>
                <option value="admin">Admin</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Scope</label>
              <select className="form-select" value={form.scope} onChange={e => setForm({ ...form, scope: e.target.value })}>
                <option value="all">All Devices</option>
                <option value="admin">Admin Only</option>
                <option value="group">Device Group</option>
                <option value="single">Single Device</option>
              </select>
            </div>
            <div className="modal-actions">
              <button className="btn btn-outline" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleCreate}>Create Policy</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
