import React, { useEffect, useState } from 'react';
import { getStats, getDevices } from '../api';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const COLORS = ['#4a9eda', '#27ae60', '#f5a623', '#e74c3c'];

export default function Dashboard() {
  const [stats, setStats] = useState({ total: 0, active: 0, provisioned: 0, lastRegistered: '-' });
  const [devices, setDevices] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    getStats()
      .then(r => setStats(r.data.data))
      .catch(() => setError('Could not connect to backend. Make sure the server is running on port 5000.'));
    getDevices()
      .then(r => setDevices(r.data.data))
      .catch(() => {});
  }, []);

  const typeData = ['sensor', 'gateway', 'actuator', 'other'].map(type => ({
    name: type.charAt(0).toUpperCase() + type.slice(1),
    count: devices.filter(d => d.type === type).length
  })).filter(d => d.count > 0);

  const statusData = [
    { name: 'Active', value: stats.active },
    { name: 'Inactive', value: stats.total - stats.active }
  ].filter(d => d.value > 0);

  return (
    <div>
      {error && <div className="alert alert-error">{error}</div>}

      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-label">Total Devices</div>
          <div className="stat-value">{stats.total}</div>
          <div className="stat-bar" />
        </div>
        <div className="stat-card">
          <div className="stat-label">Active Devices</div>
          <div className="stat-value" style={{ color: '#2ecc71' }}>{stats.active}</div>
          <div className="stat-bar" style={{ background: '#27ae60' }} />
        </div>
        <div className="stat-card">
          <div className="stat-label">Provisioned Devices</div>
          <div className="stat-value" style={{ color: '#4a9eda' }}>{stats.provisioned}</div>
          <div className="stat-bar" />
        </div>
        <div className="stat-card">
          <div className="stat-label">Last Registered</div>
          <div style={{ fontSize: 18, fontFamily: 'Rajdhani, sans-serif', fontWeight: 600, marginTop: 10, color: '#f5a623' }}>
            {stats.lastRegistered}
          </div>
          <div className="stat-bar" style={{ background: '#f5a623' }} />
        </div>
      </div>

      {devices.length > 0 && (
        <div className="chart-grid">
          <div className="chart-card">
            <div className="chart-title">Devices by Type</div>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={typeData}>
                <XAxis dataKey="name" tick={{ fill: '#9da5b4', fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#9da5b4', fontSize: 12 }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ background: '#2a2d3e', border: '1px solid #383b50', color: '#e8eaf0', borderRadius: 8 }} />
                <Bar dataKey="count" fill="#4a9eda" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="chart-card">
            <div className="chart-title">Status Distribution</div>
            {statusData.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                    {statusData.map((_, i) => <Cell key={i} fill={i === 0 ? '#27ae60' : '#e74c3c'} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: '#2a2d3e', border: '1px solid #383b50', color: '#e8eaf0', borderRadius: 8 }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="empty-state"><p>No device data yet</p></div>
            )}
          </div>
        </div>
      )}

      <div className="table-card">
        <div className="table-header">
          <span className="table-title">Recent Devices</span>
        </div>
        {devices.length === 0 ? (
          <div className="empty-state">
            <div className="icon">📡</div>
            <p>No devices registered yet</p>
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Name</th><th>Type</th><th>Status</th><th>Location</th><th>Last Seen</th>
              </tr>
            </thead>
            <tbody>
              {devices.slice(0, 5).map(d => (
                <tr key={d.id}>
                  <td>{d.name}</td>
                  <td style={{ textTransform: 'capitalize' }}>{d.type}</td>
                  <td><span className={`badge badge-${d.status}`}>{d.status}</span></td>
                  <td>{d.location}</td>
                  <td style={{ color: '#9da5b4', fontSize: 12 }}>{new Date(d.lastSeen).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
