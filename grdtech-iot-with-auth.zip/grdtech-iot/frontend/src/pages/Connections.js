import React, { useEffect, useState } from 'react';
import { getConnections, createConnection, deleteConnection, updateConnection } from '../api';

export default function Connections() {
  const [connections, setConnections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name: '', protocol: 'MQTT', host: '', port: '' });

  const load = () => {
    setLoading(true);
    getConnections().then(r => setConnections(r.data.data)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const handleCreate = async () => {
    await createConnection({ ...form, status: 'connected' });
    setShowModal(false);
    setForm({ name: '', protocol: 'MQTT', host: '', port: '' });
    load();
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Remove this connection?')) return;
    await deleteConnection(id); load();
  };

  const toggleStatus = async (c) => {
    await updateConnection(c.id, { ...c, status: c.status === 'connected' ? 'disconnected' : 'connected' });
    load();
  };

  const PROTOCOL_COLORS = { MQTT: '#4a9eda', HTTP: '#27ae60', WebSocket: '#f5a623', CoAP: '#9b59b6' };

  return (
    <div>
      <div className="section-header">
        <span className="section-title">Connection Manager</span>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>＋ Add Connection</button>
      </div>

      {loading ? (
        <div className="loading"><div className="spinner" /></div>
      ) : connections.length === 0 ? (
        <div className="empty-state"><div className="icon">🔗</div><p>No connections configured</p></div>
      ) : (
        <div className="conn-grid">
          {connections.map(c => (
            <div className="conn-card" key={c.id}>
              <div className="conn-header">
                <span className="conn-name">{c.name}</span>
                <span className="badge" style={{ background: `${PROTOCOL_COLORS[c.protocol] || '#4a9eda'}22`, color: PROTOCOL_COLORS[c.protocol] || '#4a9eda', border: `1px solid ${PROTOCOL_COLORS[c.protocol] || '#4a9eda'}44` }}>
                  {c.protocol}
                </span>
              </div>
              <div className="conn-detail"><span>Host</span><span style={{ color: '#e8eaf0' }}>{c.host}</span></div>
              <div className="conn-detail"><span>Port</span><span style={{ color: '#e8eaf0' }}>{c.port}</span></div>
              <div className="conn-detail" style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid #383b50' }}>
                <span className={`badge ${c.status === 'connected' ? 'badge-active' : 'badge-inactive'}`}>{c.status}</span>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button className="btn btn-outline btn-sm" onClick={() => toggleStatus(c)}>
                    {c.status === 'connected' ? 'Disconnect' : 'Connect'}
                  </button>
                  <button className="btn btn-danger btn-sm" onClick={() => handleDelete(c.id)}>Remove</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-title">Add Connection</div>
            <div className="form-group">
              <label className="form-label">Name</label>
              <input className="form-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Production MQTT" />
            </div>
            <div className="form-group">
              <label className="form-label">Protocol</label>
              <select className="form-select" value={form.protocol} onChange={e => setForm({ ...form, protocol: e.target.value })}>
                <option>MQTT</option><option>HTTP</option><option>WebSocket</option><option>CoAP</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Host</label>
              <input className="form-input" value={form.host} onChange={e => setForm({ ...form, host: e.target.value })} placeholder="broker.example.com" />
            </div>
            <div className="form-group">
              <label className="form-label">Port</label>
              <input className="form-input" type="number" value={form.port} onChange={e => setForm({ ...form, port: e.target.value })} placeholder="1883" />
            </div>
            <div className="modal-actions">
              <button className="btn btn-outline" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleCreate}>Add Connection</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
