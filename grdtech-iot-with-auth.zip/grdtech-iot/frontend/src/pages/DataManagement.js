import React, { useEffect, useState } from 'react';
import { getDataRecords, createDataRecord, deleteDataRecord } from '../api';

export default function DataManagement() {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ deviceId: '', dataType: 'telemetry', value: '', unit: '' });

  const load = () => {
    setLoading(true);
    getDataRecords().then(r => setRecords(r.data.data)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const handleCreate = async () => {
    await createDataRecord(form);
    setShowModal(false);
    setForm({ deviceId: '', dataType: 'telemetry', value: '', unit: '' });
    load();
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete record?')) return;
    await deleteDataRecord(id); load();
  };

  return (
    <div>
      <div className="section-header">
        <span className="section-title">Device & Data Management</span>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>＋ Add Record</button>
      </div>

      <div className="table-card">
        {loading ? (
          <div className="loading"><div className="spinner" /></div>
        ) : records.length === 0 ? (
          <div className="empty-state">
            <div className="icon">🗄️</div>
            <p>No data records yet. Add telemetry data manually.</p>
          </div>
        ) : (
          <table>
            <thead><tr><th>Device ID</th><th>Type</th><th>Value</th><th>Unit</th><th>Timestamp</th><th>Action</th></tr></thead>
            <tbody>
              {records.map(r => (
                <tr key={r.id}>
                  <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{r.deviceId}</td>
                  <td><span className="badge badge-provisioned">{r.dataType}</span></td>
                  <td><strong>{r.value}</strong></td>
                  <td style={{ color: '#9da5b4' }}>{r.unit}</td>
                  <td style={{ color: '#9da5b4', fontSize: 12 }}>{new Date(r.timestamp).toLocaleString()}</td>
                  <td><button className="btn btn-danger btn-sm" onClick={() => handleDelete(r.id)}>Delete</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-title">Add Data Record</div>
            <div className="form-group">
              <label className="form-label">Device ID</label>
              <input className="form-input" value={form.deviceId} onChange={e => setForm({ ...form, deviceId: e.target.value })} placeholder="device-uuid" />
            </div>
            <div className="form-group">
              <label className="form-label">Data Type</label>
              <select className="form-select" value={form.dataType} onChange={e => setForm({ ...form, dataType: e.target.value })}>
                <option value="telemetry">Telemetry</option>
                <option value="event">Event</option>
                <option value="alert">Alert</option>
                <option value="log">Log</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Value</label>
              <input className="form-input" value={form.value} onChange={e => setForm({ ...form, value: e.target.value })} placeholder="24.5" />
            </div>
            <div className="form-group">
              <label className="form-label">Unit</label>
              <input className="form-input" value={form.unit} onChange={e => setForm({ ...form, unit: e.target.value })} placeholder="°C, %, mbps" />
            </div>
            <div className="modal-actions">
              <button className="btn btn-outline" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleCreate}>Save Record</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
