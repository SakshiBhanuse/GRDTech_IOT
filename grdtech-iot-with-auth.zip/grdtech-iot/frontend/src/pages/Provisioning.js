import React, { useEffect, useState } from 'react';
import { getDevices, provisionDevice } from '../api';

export default function Provisioning() {
  const [devices, setDevices] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    getDevices().then(r => setDevices(r.data.data)).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const handleProvision = async (id) => {
    await provisionDevice(id); load();
  };

  const unprovisioned = devices.filter(d => !d.provisioned);
  const provisioned = devices.filter(d => d.provisioned);

  return (
    <div>
      <div className="section-header">
        <span className="section-title">Device Provisioning</span>
        <span style={{ color: '#9da5b4', fontSize: 14 }}>{unprovisioned.length} pending</span>
      </div>

      {unprovisioned.length > 0 && (
        <>
          <div style={{ color: '#f5a623', marginBottom: 12, fontSize: 14, fontWeight: 500 }}>⚠️ Pending Provisioning</div>
          <div className="table-card" style={{ marginBottom: 24 }}>
            {loading ? <div className="loading"><div className="spinner" /></div> : (
              <table>
                <thead><tr><th>Name</th><th>Type</th><th>Location</th><th>IP</th><th>Action</th></tr></thead>
                <tbody>
                  {unprovisioned.map(d => (
                    <tr key={d.id}>
                      <td><strong>{d.name}</strong></td>
                      <td style={{ textTransform: 'capitalize' }}>{d.type}</td>
                      <td>{d.location}</td>
                      <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{d.ip}</td>
                      <td><button className="btn btn-success btn-sm" onClick={() => handleProvision(d.id)}>✓ Provision Now</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}

      <div style={{ color: '#2ecc71', marginBottom: 12, fontSize: 14, fontWeight: 500 }}>✓ Provisioned Devices ({provisioned.length})</div>
      <div className="table-card">
        {provisioned.length === 0 ? (
          <div className="empty-state"><div className="icon">🔧</div><p>No provisioned devices yet</p></div>
        ) : (
          <table>
            <thead><tr><th>Name</th><th>Type</th><th>Status</th><th>Location</th><th>Firmware</th><th>Last Seen</th></tr></thead>
            <tbody>
              {provisioned.map(d => (
                <tr key={d.id}>
                  <td><strong>{d.name}</strong></td>
                  <td style={{ textTransform: 'capitalize' }}>{d.type}</td>
                  <td><span className={`badge badge-${d.status}`}>{d.status}</span></td>
                  <td>{d.location}</td>
                  <td style={{ color: '#9da5b4' }}>{d.firmware}</td>
                  <td style={{ color: '#9da5b4', fontSize: 12 }}>{new Date(d.lastSeen).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
