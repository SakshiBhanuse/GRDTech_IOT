import axios from 'axios';

const API = axios.create({ baseURL: 'http://localhost:5000/api' });

// Attach JWT token to every request automatically
API.interceptors.request.use((config) => {
  const token = localStorage.getItem('grdtech_token');
  if (token) {
    config.headers['Authorization'] = `Bearer ${token}`;
  }
  return config;
});

// If token expires, redirect to login
API.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('grdtech_token');
      localStorage.removeItem('grdtech_user');
      window.location.reload();
    }
    return Promise.reject(error);
  }
);

// Auth
export const loginUser    = (data) => API.post('/auth/login', data);
export const registerUser = (data) => API.post('/auth/register', data);
export const getMe        = ()     => API.get('/auth/me');
export const logoutUser   = ()     => API.post('/auth/logout');

// Devices
export const getStats       = ()         => API.get('/devices/stats');
export const getDevices     = ()         => API.get('/devices');
export const createDevice   = (data)     => API.post('/devices', data);
export const updateDevice   = (id, data) => API.put(`/devices/${id}`, data);
export const deleteDevice   = (id)       => API.delete(`/devices/${id}`);
export const provisionDevice = (id)      => API.post(`/devices/${id}/provision`);

// Features
export const getFeatures   = ()         => API.get('/features');
export const updateFeature = (id, data) => API.put(`/features/${id}`, data);
export const createFeature = (data)     => API.post('/features', data);

// Connections
export const getConnections    = ()         => API.get('/connections');
export const createConnection  = (data)     => API.post('/connections', data);
export const updateConnection  = (id, data) => API.put(`/connections/${id}`, data);
export const deleteConnection  = (id)       => API.delete(`/connections/${id}`);

// Policies
export const getPolicies    = ()         => API.get('/policies');
export const createPolicy   = (data)     => API.post('/policies', data);
export const updatePolicy   = (id, data) => API.put(`/policies/${id}`, data);
export const deletePolicy   = (id)       => API.delete(`/policies/${id}`);

// Data
export const getDataRecords    = ()     => API.get('/data');
export const createDataRecord  = (data) => API.post('/data', data);
export const deleteDataRecord  = (id)   => API.delete(`/data/${id}`);
